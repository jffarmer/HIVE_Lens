/** Automatically generated file. DO NOT MODIFY */
package com.capstone.StoryOne;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}